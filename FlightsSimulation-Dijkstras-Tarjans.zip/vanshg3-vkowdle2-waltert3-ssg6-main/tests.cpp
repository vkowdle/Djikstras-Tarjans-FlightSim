#include "catch.hpp"
#include "data.h"
#include "graph.h"

TEST_CASE("List::insertFront size", "[weight=1][part=1][valgrind]") {

    REQUIRE( true );
}
